# Sachin: portfolio
Static site (no build step). Open `index.html`, or push the folder to GitHub Pages / Vercel / Netlify.
- Photo: drop a square `photo.jpg` into `assets/` (falls back to the monogram until then).
- Résumé: replace `resume.pdf` to update the download.
- Content lives in `js/main.js` (projects, LeetCode skills, stack) and `index.html` (copy).
- Project screenshots: save PNGs as `assets/shots/quickfolio.png`, `path-lab.png`, `proofpay.png`, `studyos.png` (16:10 works best). They replace the generated covers automatically.
